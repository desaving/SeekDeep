# SeekDeep Android

把现在网页版打包成可安装的 APK。网页资源已经内置在 `app/src/main/assets/www`，装好后不需要电脑或本地服务。

## 编译步骤

1. 电脑装 Android Studio（自带 JDK 和 Gradle）。
2. 解压本工程，Android Studio 里 File → Open，选 `seekdeep-android` 文件夹。
3. 第一次打开会提示安装 SDK；选 Android 14 (API 34)，等 Gradle 同步完成。
4. 菜单 Build → Build App Bundle(s) / APK(s) → Build APK(s)。
5. 完成后点提示里的 locate，APK 在：
   `app/build/outputs/apk/debug/app-debug.apk`
6. 把 APK 传到手机安装，允许“安装未知应用”。

## 说明

- 这是 debug 签名，自己用没问题；要上架才需要正式签名。
- 聊天记录和 API key 存在这个 App 自己的 WebView 存储里，卸载会清空。
- 附件按钮走系统文件选择器，已接好。
- 内置网页不含 Service Worker，不需要联网加载页面，只有聊天请求走网络。
- 导出历史对话用的是浏览器下载，WebView 默认不处理，可能点了没反应；需要的话再补 DownloadListener。
