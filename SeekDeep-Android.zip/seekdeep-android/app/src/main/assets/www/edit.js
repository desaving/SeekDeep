(function(){
  if(window.__dsbEdit) return; window.__dsbEdit=1;
  var st=document.createElement('style');
  st.textContent=[
    '#dsb-editbar{position:fixed;left:50%;top:calc(env(safe-area-inset-top,0px) + 8px);transform:translateX(-50%);z-index:2147483646;background:#4d6bfe;color:#fff;font-size:12px;border-radius:999px;padding:6px 10px;display:flex;gap:10px;align-items:center;box-shadow:0 2px 10px rgba(0,0,0,.2)}',
    '#dsb-editbar[hidden]{display:none}',
    '#dsb-editbar button{border:0;background:rgba(255,255,255,.2);color:#fff;font-size:12px;border-radius:999px;padding:3px 8px}'
  ].join('');
  document.head.appendChild(st);

  function lab(el){return el.getAttribute('aria-label')||''}
  function isEdit(el){ var l=lab(el); return l.indexOf('编辑')===0 || l==='Edit' || l==='Edit message'; }
  function isSend(el){ var l=lab(el); return l==='发送' || l==='Send'; }

  function findMsg(el){
    var n=el;
    for(var i=0;i<15&&n;i++,n=n.parentElement){
      var bs=n.querySelectorAll('button[aria-label]'), eb=null;
      for(var j=0;j<bs.length;j++){ if(isEdit(bs[j])){ eb=bs[j]; break; } }
      if(eb && n.querySelector('[class*="bubble"]')){
        var bub=n.querySelector('[class*="bubble"]');
        return {root:n,edit:eb,text:(bub.innerText||'').trim()};
      }
    }
    return null;
  }

  function composer(){ return document.querySelector('textarea[placeholder]'); }
  function setVal(el,v){
    var s=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value').set;
    s.call(el,v);
    el.dispatchEvent(new Event('input',{bubbles:true}));
  }
  function bar(){
    var b=document.getElementById('dsb-editbar');
    if(!b){
      b=document.createElement('div'); b.id='dsb-editbar';
      b.innerHTML='<span>编辑中，发送即保存</span><button type="button">取消</button>';
      document.body.appendChild(b);
      b.querySelector('button').onclick=function(e){ e.stopPropagation(); cancelEdit(); };
    }
    b.hidden=false;
  }
  function hideBar(){ var b=document.getElementById('dsb-editbar'); if(b) b.hidden=true; }

  var editing=null, committing=false;
  function startEdit(m){
    var ta=composer(); if(!ta) return;
    editing={msg:m,prev:ta.value};
    var wrap=ta.parentElement;
    var t1=ta.style.transition, t2=wrap?wrap.style.transition:'';
    ta.style.transition='none'; if(wrap) wrap.style.transition='none';
    setVal(ta,m.text);
    requestAnimationFrame(function(){
      ta.style.transition=t1; if(wrap) wrap.style.transition=t2;
      try{ ta.focus({preventScroll:true}); }catch(e){ try{ta.focus()}catch(x){} }
    });
    bar();
  }
  function cancelEdit(){
    if(!editing) return;
    var ta=composer(); if(ta) setVal(ta, editing.prev||'');
    editing=null; hideBar();
  }
  function commitEdit(){
    var m=editing.msg; var c=composer(); var text=c?c.value:'';
    editing=null; hideBar();
    committing=true; m.edit.click(); committing=false;
    setTimeout(function(){
      var tas=m.root.querySelectorAll('textarea');
      var ta=tas[tas.length-1]; if(!ta) return;
      if(ta.parentElement) ta.parentElement.style.display='none';
      setVal(ta,text);
      setTimeout(function(){
        var bs=m.root.querySelectorAll('button');
        for(var i=0;i<bs.length;i++){
          if((isSend(bs[i]) || (bs[i].textContent||'').trim()==='发送') && !bs[i].disabled){ bs[i].click(); break; }
        }
        var cc=composer(); if(cc) setVal(cc,'');
      },40);
    },60);
  }

  document.addEventListener('click',function(e){
    var eb=e.target.closest&&e.target.closest('button[aria-label]');
    if(eb && isEdit(eb) && !committing){
      e.preventDefault(); e.stopPropagation();
      var mm=findMsg(eb);
      if(mm) startEdit(mm);
      return;
    }
    if(!editing) return;
    var b=e.target.closest&&e.target.closest('button[aria-label]');
    if(b && isSend(b)){ e.preventDefault(); e.stopPropagation(); commitEdit(); }
  },true);

  document.addEventListener('pointerdown',function(e){
    if(!editing) return;
    var t=e.target;
    if(t.closest&&(t.closest('#dsb-editbar')||t.closest('textarea[placeholder]'))) return;
    var b=t.closest&&t.closest('button[aria-label]');
    if(b&&isSend(b)) return;
    cancelEdit();
  },true);
})();
