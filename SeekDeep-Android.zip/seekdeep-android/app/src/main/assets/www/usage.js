(function(){
  var HIT=[0.02,0.04], MISS=[1,2], OUT=[4,8];
  function peak(){
    var d=new Date(), w=d.getDay(); if(w===0||w===6) return false;
    var h=d.getHours()+d.getMinutes()/60;
    return (h>=9&&h<12)||(h>=14&&h<18);
  }
  function read(res){
    var r=res.body.getReader(), dec=new TextDecoder(), buf='';
    var hit=0, miss=0, out=0, done=false;
    function handle(line){
      if(line.indexOf('data:')!==0) return;
      var js=line.slice(5).trim(); if(!js||js==='[DONE]') return;
      try{
        var o=JSON.parse(js);
        if(o.type==='message_start'&&o.message&&o.message.usage){
          var u=o.message.usage;
          miss=Math.max(miss,(u.input_tokens||0)+(u.cache_creation_input_tokens||0));
          hit=Math.max(hit,u.cache_read_input_tokens||0);
        }
        if(o.type==='message_delta'&&o.usage){
          out=Math.max(out,o.usage.output_tokens||0);
        }
      }catch(e){}
    }
    function finish(){
      if(done) return; done=true;
      if(hit+miss+out<=0) return;
      var p=peak()?1:0;
      var cost=(hit*HIT[p]+miss*MISS[p]+out*OUT[p])/1000000;
      try{
        localStorage.setItem('dsb-last-use',JSON.stringify({hit:hit,miss:miss,out:out,cost:cost,t:Date.now()}));
      }catch(e){}
    }
    function pump(){
      r.read().then(function(x){
        if(x.done){ if(buf) handle(buf); finish(); return; }
        buf+=dec.decode(x.value,{stream:true});
        var i;
        while((i=buf.indexOf('\n'))>=0){ var line=buf.slice(0,i).replace(/\r$/,''); buf=buf.slice(i+1); if(line) handle(line); }
        pump();
      }).catch(function(){ finish(); });
    }
    pump();
  }
  var of=window.fetch;
  window.fetch=function(input,init){
    var p=of.apply(this,arguments);
    try{
      if(init&&init.method==='POST'&&typeof init.body==='string'&&init.body.indexOf('"stream"')>=0){
        p.then(function(res){ try{ if(res&&res.ok&&res.body) read(res.clone()); }catch(e){} }).catch(function(){});
      }
    }catch(e){}
    return p;
  };
})();
