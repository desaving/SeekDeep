(function(){
  function visible(el){
    setTimeout(function(){
      try{ el.scrollIntoView({block:'center',behavior:'smooth'}); }catch(e){}
    },260);
  }

  function composerTop(){
    var c=document.querySelector('textarea[placeholder]');
    if(!c) return window.innerHeight;
    return c.getBoundingClientRect().top - 20;
  }
  function scrollable(el){
    var n=el;
    while(n && n!==document.body){
      var st=getComputedStyle(n);
      if((st.overflowY==='auto'||st.overflowY==='scroll') && n.scrollHeight>n.clientHeight+2) return n;
      n=n.parentElement;
    }
    return null;
  }
  function clearOfComposer(el){
    var vv=window.visualViewport;
    if(!vv || (window.innerHeight-vv.height)<80) return;
    var limit=composerTop();
    var r=el.getBoundingClientRect();
    if(r.bottom<=limit-6) return;
    var delta=r.bottom-limit+14;
    var sc=scrollable(el);
    if(sc) sc.scrollTop+=delta;
    else window.scrollBy(0,delta);
  }

  var inlineEdit=false;
  document.addEventListener('focusin',function(e){
    var t=e.target;
    if(!t) return;
    inlineEdit = !!(t.tagName==='TEXTAREA' && (t.getAttribute('aria-label')||'').indexOf('编辑')===0);
    if(t.tagName==='TEXTAREA' || (t.tagName==='INPUT' && t.type!=='file')){
      visible(t);
      setTimeout(function(){ visible(t); },700);
      if(inlineEdit){
        [300,650,1000].forEach(function(ms){ setTimeout(function(){ try{ clearOfComposer(t); }catch(e){} },ms); });
      }
    }
  });
  document.addEventListener('focusout',function(){
    setTimeout(function(){ inlineEdit=false; },120);
  });

  var vv=window.visualViewport;
  if(!vv) return;
  var root=null;
  function fit(){
    if(!root) root=document.getElementById('root');
    if(!root) return;
    var kb=Math.max(0, window.innerHeight - vv.height - vv.offsetTop);
    if(kb>80){
      root.style.transform='translateY(-'+kb+'px)';
      root.style.height=vv.height+'px';
      root.style.overflow='hidden';
    }else{
      root.style.transform='';
      root.style.height='';
      root.style.overflow='';
    }
  }
  vv.addEventListener('resize',fit);
  vv.addEventListener('scroll',fit);
  window.addEventListener('orientationchange',function(){setTimeout(fit,300)});
  setTimeout(fit,500);
})();

/* 手机回车只换行，发送用右下角按钮；Ctrl/Cmd+Enter 仍然发送 */
document.addEventListener('keydown', function(e){
  var t=e.target;
  if(!t || t.tagName!=='TEXTAREA') return;
  if(e.key!=='Enter' || e.isComposing) return;
  if(e.ctrlKey || e.metaKey) return;
  e.stopPropagation();
}, true);

/* 去掉底部“内容由 AI 生成”提示 */
(function(){
  function hideIn(root){
    if(!root || !root.querySelectorAll) return;
    var els=root.querySelectorAll('*');
    for(var i=0;i<els.length;i++){
      var el=els[i];
      if(el.children.length===0 && (el.textContent||'').trim().indexOf('内容由 AI 生成')===0){
        var n=el;
        for(var k=0;k<3;k++){
          n.style.display='none';
          var p=n.parentElement;
          if(!p || p===document.body) break;
          if(p.children.length!==1) break;
          n=p;
        }
      }
    }
  }
  hideIn(document.body);
  setTimeout(function(){ hideIn(document.body); },600);
  setTimeout(function(){ hideIn(document.body); },2000);
  try{
    new MutationObserver(function(muts){
      for(var i=0;i<muts.length;i++){
        var a=muts[i].addedNodes;
        for(var j=0;j<a.length;j++){
          var n=a[j];
          if(n.nodeType===1 && (n.textContent||'').indexOf('内容由 AI 生成')>=0) hideIn(n);
        }
      }
    }).observe(document.body,{childList:true,subtree:true});
  }catch(e){}
})();

/* 把版本号放到侧栏标题 SeekDeep 后面 */
(function(){
  var tag='dsb-brand-ver';
  function put(){
    var v=window.DSB_VERSION||''; if(!v) return;
    if(document.querySelector('.'+tag)) return;
    var els=document.body.querySelectorAll('div,span,h1,h2,h3,a');
    for(var i=0;i<els.length;i++){
      var el=els[i];
      if(el.children.length!==0) continue;
      if((el.textContent||'').trim()!=='SeekDeep') continue;
      var s=document.createElement('span');
      s.className=tag; s.textContent=v;
      s.style.cssText='font-size:.65em;color:inherit;margin-left:.35em;font-weight:inherit;vertical-align:baseline;opacity:.9';
      el.appendChild(s);
      break;
    }
  }
  setTimeout(put,600); setTimeout(put,1800);
  try{
    var t=0;
    new MutationObserver(function(){ clearTimeout(t); t=setTimeout(put,300); }).observe(document.body,{childList:true,subtree:true});
  }catch(e){}
})();

/* 把页面的浅色/深色同步给安卓外壳的状态栏 */
(function(){
  function dark(){
    try{
      var p=localStorage.getItem('chat-demo:theme-preference')||'system';
      if(p==='dark') return true;
      if(p==='light') return false;
      return !!(window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches);
    }catch(e){ return false; }
  }
  function push(){ try{ if(window.Android&&window.Android.setUi) window.Android.setUi(!!dark()); }catch(e){} }
  var o=localStorage.setItem;
  localStorage.setItem=function(k,v){ o.call(localStorage,k,v); if(k==='chat-demo:theme-preference') setTimeout(push,0); };
  try{ if(window.matchMedia) matchMedia('(prefers-color-scheme: dark)').addEventListener('change',push); }catch(e){}
  setTimeout(push,600);
})();
