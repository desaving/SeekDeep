(function(){
  var KEY='chat-demo:api-key';
  var API='https://api.deepseek.com/user/balance';
  var TOPUP='https://platform.deepseek.com/top_up';
  var timer=null, opened=false, data=null, lastBin=null, lastAvail=true, statsOpen=false;

  var css=[
    '#dsb-wrap{position:fixed;left:auto;right:8px;top:calc(env(safe-area-inset-top,0px) + 56px);z-index:2147483000;display:block;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,"PingFang SC","Microsoft YaHei",sans-serif}',
    '#dsb-btn{appearance:none;border:0;cursor:grab;touch-action:none;user-select:none;-webkit-user-select:none;background:#4d6bfe;color:#fff;font-size:12px;line-height:1;padding:9px 11px;border-radius:999px;box-shadow:0 2px 8px rgba(0,0,0,.18);white-space:nowrap;font-weight:600}',
    '#dsb-btn:active{transform:scale(.97)}',
    '#dsb-wrap.dragging #dsb-btn{cursor:grabbing;opacity:.85}',
    '#dsb-panel{position:absolute;top:calc(100% + 8px);right:0;width:206px;background:#fff;color:#222;border-radius:12px;box-shadow:0 6px 24px rgba(0,0,0,.18);padding:12px 13px;font-size:13px;line-height:1.5}',
    '#dsb-panel[hidden]{display:none}',
    '#dsb-panel .dsb-row{display:flex;justify-content:space-between;gap:10px;margin:3px 0}',
    '#dsb-panel .dsb-k{color:#888}',
    '#dsb-panel .dsb-total{font-size:18px;font-weight:700;margin:2px 0 6px}',
    '#dsb-panel{max-height:72vh;overflow-y:auto}',
    '#dsb-panel .dsb-bars{display:flex;gap:4px;align-items:flex-end;height:48px;margin:4px 0 6px}',
    '#dsb-panel .dsb-bar{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%}',
    '#dsb-panel .dsb-bar i{display:block;width:70%;background:#4d6bfe;border-radius:2px;min-height:2px}',
    '#dsb-panel .dsb-bar b{font-size:8px;color:#999;font-weight:400;margin-top:2px;transform:scale(.9)}',
    '#dsb-panel .dsb-hrow{display:flex;align-items:center;gap:6px;margin:3px 0}',
    '#dsb-panel .dsb-hrow .d{width:34px;color:#888;font-size:11px}',
    '#dsb-panel .dsb-hrow .bar{flex:1;height:6px;background:#eee;border-radius:3px;overflow:hidden}',
    '#dsb-panel .dsb-hrow .bar i{display:block;height:100%;background:#4d6bfe}',
    '#dsb-panel .dsb-hrow .v{width:48px;text-align:right;font-size:11px}',
    '#dsb-panel .dsb-stats-head{display:flex;align-items:center;gap:8px;margin-bottom:6px;font-size:12px}',
    '#dsb-panel .dsb-stats-head button{border:0;background:none;color:#4d6bfe;font-size:12px;padding:0}',
    '#dsb-panel .dsb-mhead,#dsb-panel .dsb-mrow3{display:flex;align-items:center;gap:6px;margin:4px 0}',
    '#dsb-panel .dsb-mhead{font-size:10px;color:#999}',
    '#dsb-panel .dsb-mhead .m,#dsb-panel .dsb-mrow3 .m{width:40px}',
    '#dsb-panel .dsb-mhead .c,#dsb-panel .dsb-mrow3 .c{flex:1;text-align:right;font-size:11px}',
    '#dsb-panel .dsb-mrow3 .c{position:relative;padding:0 2px}',
    
    
    '#dsb-panel .dsb-period{margin:6px 0}',
    '#dsb-panel .dsb-note{font-size:10px;color:#999;margin-top:6px}',
    '#dsb-panel .dsb-more{border:0;background:none;color:#4d6bfe;font-size:12px;padding:0}',
    '#dsb-stats{position:fixed;inset:0;z-index:2147483600;background:#fff;color:#222;display:flex;flex-direction:column}',
    '#dsb-stats .dsb-statbar{display:flex;align-items:center;gap:10px;padding:10px 12px;border-bottom:1px solid #eee;font-size:14px}',
    '#dsb-stats .dsb-statbar button{border:0;background:none;color:#4d6bfe;font-size:15px}',
    '#dsb-stats .dsb-statbody{flex:1;overflow:auto;padding:12px}',
    '#dsb-stats .dsb-mrow{display:flex;align-items:center;gap:8px;margin:8px 0;font-size:12px}',
    '#dsb-stats .dsb-mrow .m{width:56px;color:#888}',
    '#dsb-stats .dsb-mrow .bar{flex:1;height:8px;background:#eee;border-radius:4px;overflow:hidden}',
    '#dsb-stats .dsb-mrow .bar i{display:block;height:100%;background:#4d6bfe}',
    '#dsb-stats .dsb-mrow .v{width:58px;text-align:right}',
    '#dsb-stats .dsb-note{font-size:11px;color:#999;margin-top:12px}',
    '@media (prefers-color-scheme:dark){#dsb-stats{background:#1e1e20;color:#eee}#dsb-stats .dsb-statbar{border-bottom-color:#333}#dsb-stats .dsb-mrow .m{color:#999}#dsb-stats .dsb-mrow .bar{background:#333}}',
    '#dsb-panel .dsb-ver{font-size:10px;color:#aaa;margin-top:6px;text-align:right}',
    '#dsb-panel .dsb-actions{display:flex;justify-content:space-between;margin-top:8px;padding-top:8px;border-top:1px solid #eee}',
    '#dsb-panel a,#dsb-panel button{color:#4d6bfe;background:none;border:0;padding:0;font-size:12px;cursor:pointer;text-decoration:none}',
    '#dsb-wrap.dsb-left #dsb-panel{left:0;right:auto}',
    '#dsb-wrap.dsb-up #dsb-panel{top:auto;bottom:calc(100% + 8px)}',
    '#dsb-topup{position:fixed;inset:0;z-index:2147483600;background:#fff;display:flex;flex-direction:column}',
    '#dsb-topup .dsb-bar{display:flex;align-items:center;gap:8px;padding:10px 12px;border-bottom:1px solid #eee;font-size:14px}',
    '#dsb-topup .dsb-bar button{border:0;background:none;color:#4d6bfe;font-size:15px;padding:4px 6px}',
    '#dsb-topup .dsb-title{font-weight:600;color:#222}',
    '#dsb-topup .dsb-bar a{margin-left:auto;font-size:12px;color:#999;text-decoration:none}',
    '#dsb-topup iframe{flex:1;border:0;width:100%;background:#fff}',
    '@media (prefers-color-scheme:dark){#dsb-topup{background:#1e1e20}#dsb-topup .dsb-bar{border-bottom-color:#333}#dsb-topup .dsb-title{color:#eee}}',
    '@media (prefers-color-scheme:dark){#dsb-panel .dsb-hrow .bar{background:#333}#dsb-panel .dsb-hrow .d,#dsb-panel .dsb-hrow .v{color:#aaa}#dsb-panel{background:#1e1e20;color:#eee}#dsb-panel .dsb-k{color:#9a9a9a}#dsb-panel .dsb-actions{border-top-color:#333}}'
  ].join('');
  var st=document.createElement('style'); st.textContent=css; document.head.appendChild(st);

  var wrap=document.createElement('div'); wrap.id='dsb-wrap';
  wrap.innerHTML='<button id="dsb-btn" type="button">¥ --</button><div id="dsb-panel" hidden></div>';
  document.body.appendChild(wrap);
  var btn=wrap.querySelector('#dsb-btn'), panel=wrap.querySelector('#dsb-panel');

  function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
  function money(v){var n=Number(v);return isNaN(n)?String(v):n.toFixed(2)}


  function pad2(n){ return n<10?'0'+n:''+n; }
  function dayKey(d){ return d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate()); }
  function dailyMap(){ try{ return JSON.parse(localStorage.getItem('dsb-daily')||'{}')||{}; }catch(e){ return {}; } }
  function saveDaily(o){ try{ localStorage.setItem('dsb-daily',JSON.stringify(o)); }catch(e){} }
  function topupMap(){ try{ return JSON.parse(localStorage.getItem('dsb-topup')||'{}')||{}; }catch(e){ return {}; } }
  function saveTopup(o){ try{ localStorage.setItem('dsb-topup',JSON.stringify(o)); }catch(e){} }
  function trackSpend(b){
    var cur=Number(b.total_balance);
    if(isNaN(cur)) return;
    var k=dayKey(new Date());
    var day=null;
    try{ day=JSON.parse(localStorage.getItem('dsb-day')||'null'); }catch(e){}
    if(day && day.d!==k){
      var po=dailyMap();
      po[day.d]=Math.round(Math.max(0,Number(day.a)-cur)*10000)/10000;
      saveDaily(po);
      var lastN=Number(day.last);
      if(!isNaN(lastN) && cur>lastN+4.5){
        var addT=Math.round(cur-lastN);
        if(addT>0){
          var tm0=topupMap();
          tm0[k]=Math.round(((tm0[k]||0)+addT)*10000)/10000;
          saveTopup(tm0);
        }
      }
    }
    if(!day || day.d!==k){
      day={d:k,a:cur,last:cur};
    }else{
      var last=Number(day.last);
      if(!isNaN(last) && cur>last+4.5){
        var raw=cur-last;
        var add=Math.round(raw);
        day.a=Number(day.a)+add;
        var tm=topupMap(), tk=k;
        tm[tk]=Math.round(((tm[tk]||0)+add)*10000)/10000;
        var tks=Object.keys(tm).sort(); while(tks.length>400){ delete tm[tks.shift()]; }
        saveTopup(tm);
      }
      day.last=cur;
    }
    try{ localStorage.setItem('dsb-day',JSON.stringify(day)); }catch(e){}
    var spend=Math.max(0, Number(day.a)-cur);
    var o=dailyMap();
    o[k]=Math.round(spend*10000)/10000;
    var keys=Object.keys(o).sort();
    while(keys.length>400){ delete o[keys.shift()]; }
    saveDaily(o);
  }
  function spendBlock(){
    var o=dailyMap(), tp=topupMap(), now=new Date(), days=[], sum30=0, sum7top=0, sum30top=0;
    for(var i=0;i<=6;i++){
      var d=new Date(now.getFullYear(),now.getMonth(),now.getDate()-i);
      days.push({label:(d.getMonth()+1)+'/'+d.getDate(), v:Number(o[dayKey(d)]||0)});
    }
    for(var k2 in o){
      var t=new Date(k2+'T00:00:00');
      if(!isNaN(t) && (now-t)/86400000 < 30) sum30+=Number(o[k2]||0);
    }
    for(var k3 in tp){
      var t3=new Date(k3+'T00:00:00');
      if(!isNaN(t3)){
        var dd=(now-t3)/86400000;
        if(dd<7) sum7top+=Number(tp[k3]||0);
        if(dd<30) sum30top+=Number(tp[k3]||0);
      }
    }
    var max=0.01; days.forEach(function(x){ if(x.v>max) max=x.v; });
    var sum7=0; days.forEach(function(x){ sum7+=x.v; });
    var rows=days.map(function(x){
      var w=Math.max(2,Math.round(x.v/max*100));
      return '<div class="dsb-hrow"><span class="d">'+x.label+'</span><span class="bar"><i style="width:'+w+'%"></i></span><span class="v">¥'+x.v.toFixed(2)+'</span></div>';
    }).join('');
    return '<div class="dsb-spend"><div class="dsb-k">近七日消耗</div>'+rows+
      '<div class="dsb-period"><div class="dsb-k">近一周</div><div class="dsb-row"><span>消耗 ¥'+sum7.toFixed(2)+'</span><span>充值 ¥'+sum7top.toFixed(2)+'</span></div></div>'+
      '<div class="dsb-period"><div class="dsb-k">近一月</div><div class="dsb-row"><span>消耗 ¥'+sum30.toFixed(2)+'</span><span>充值 ¥'+sum30top.toFixed(2)+'</span></div></div>'+
      '<div class="dsb-row"><button type="button" class="dsb-more">更多数据 ›</button></div></div>';
  }

  function monthTotals(){
    var o=dailyMap(), tp=topupMap(), now=new Date(), out=[];
    for(var i=0;i<=11;i++){
      var d=new Date(now.getFullYear(),now.getMonth()-i,1);
      var key=d.getFullYear()+'-'+pad2(d.getMonth()+1);
      var sum=0, top=0;
      for(var k in o){ if(k.indexOf(key)===0) sum+=Number(o[k]||0); }
      for(var k2 in tp){ if(k2.indexOf(key)===0) top+=Number(tp[k2]||0); }
      out.push({label:key,v:sum,t:top});
    }
    return out;
  }
  function showStats(){
    statsOpen=true;
    var list=monthTotals(), maxS=0.01, maxT=0.01;
    list.forEach(function(x){ if(x.v>maxS) maxS=x.v; if(x.t>maxT) maxT=x.t; });
    var head='<div class="dsb-mhead"><span class="m">月份</span><span class="c">消耗</span><span class="c">充值</span></div>';
    var rows=list.map(function(x){
      var ws=Math.max(2,Math.round(x.v/maxS*100)), wt=Math.max(2,Math.round(x.t/maxT*100));
      var gs=x.v>0?' style="background:linear-gradient(to right,rgba(77,107,254,.18) '+Math.min(ws,72)+'%,transparent '+Math.min(ws,72)+'%)"':'';
      var gt=x.t>0?' style="background:linear-gradient(to right,rgba(77,107,254,.18) '+Math.min(wt,72)+'%,transparent '+Math.min(wt,72)+'%)"':'';
      return '<div class="dsb-mrow3"><span class="m">'+x.label.slice(2)+'</span>'+
        '<span class="c"'+gs+'>¥'+x.v.toFixed(2)+'</span>'+
        '<span class="c"'+gt+'>¥'+x.t.toFixed(2)+'</span></div>';
    }).join('');
    panel.hidden=false;
    panel.innerHTML='<div class="dsb-stats-head"><button type="button" id="dsb-back">‹ 返回</button><span>月度消耗与充值</span></div>'+head+rows;
    panel.querySelector('#dsb-back').onclick=function(e){ e.stopPropagation(); statsOpen=false; if(lastBin) paint(lastBin,lastAvail); else load(true); };
  }

  function verLine(){ return '<div class="dsb-ver">'+(window.DSB_VERSION||'')+'</div>'; }

  function paint(binfo,available){
    data=binfo; lastBin=binfo; lastAvail=available;
    if(statsOpen) return;
    var total=money(binfo.total_balance);
    btn.textContent='¥ '+total;
    var rows='<div class="dsb-total">余额 ¥'+total+'</div>';
    rows+='<div class="dsb-row"><span class="dsb-k">状态</span><span>'+(available?'可用':'余额不足')+'</span></div>';
    var lu=null; try{ lu=JSON.parse(localStorage.getItem('dsb-last-use')||'null'); }catch(e){}
    if(lu){
      var tot=(lu.hit||0)+(lu.miss||0)+(lu.out||0);
      var rate=(lu.hit+lu.miss)>0?Math.round(lu.hit/(lu.hit+lu.miss)*100):0;
      rows+='<div class="dsb-k" style="margin-top:8px">近一次使用</div>';
      rows+='<div class="dsb-row" style="font-size:10px"><span>'+tot.toLocaleString()+' tokens</span><span>缓存 '+rate+'%</span><span>¥'+(Number(lu.cost)||0).toFixed(4)+'</span></div>';
    }
    rows+='<div class="dsb-actions"><button type="button" id="dsb-refresh">刷新</button><button type="button" class="dsb-topup">去充值</button></div>';
    rows+=spendBlock();
    panel.innerHTML=rows;
    bindTopup();
    var rf=panel.querySelector('#dsb-refresh');
    if(rf) rf.onclick=function(e){e.stopPropagation();load(true)};
  }

  function fail(msg){
    btn.textContent='¥ --';
    panel.innerHTML='<div>'+esc(msg)+'</div>'+'<div class="dsb-actions"><button type="button" id="dsb-refresh">重试</button><button type="button" class="dsb-topup">去充值</button></div>'+spendBlock();
    var rf=panel.querySelector('#dsb-refresh');
    if(rf) rf.onclick=function(e){e.stopPropagation();load(true)};
    bindTopup();
  }

  var loading=false;
  function load(force){
    if(loading) return;
    loading=true;
    var key=localStorage.getItem(KEY);
    if(!key){ loading=false; fail('还没有填 API key'); return; }
    if(force){ btn.textContent='¥ …'; }
    fetch(API,{headers:{'Authorization':'Bearer '+key},cache:'no-store'}).then(function(r){
      if(r.status===401){ fail('API key 无效'); return null; }
      if(!r.ok) throw new Error('HTTP '+r.status);
      return r.json();
    }).then(function(d){
      if(!d) return;
      var infos=d.balance_infos||[];
      var b=infos.filter(function(x){return x.currency==='CNY'})[0]||infos[0];
      if(!b){ fail('没有余额信息'); return; }
      trackSpend(b);
      paint(b, d.is_available);
    }).catch(function(){ fail('余额读取失败'); }).finally(function(){ loading=false; });
  }

  var PKEY='dsb-pos', justDragged=false, dragging=false, moved=false, sx=0, sy=0, ox=0, oy=0;

  function clampPos(x,y){
    var w=wrap.offsetWidth||62, h=wrap.offsetHeight||34;
    x=Math.max(4,Math.min(x,window.innerWidth-w-4));
    y=Math.max(4,Math.min(y,window.innerHeight-h-4));
    return {x:x,y:y};
  }
  function place(x,y,save){
    var p=clampPos(x,y);
    wrap.style.left=p.x+'px'; wrap.style.top=p.y+'px'; wrap.style.right='auto';
    wrap.classList.toggle('dsb-left', p.x < window.innerWidth/2);
    wrap.classList.toggle('dsb-up', p.y > window.innerHeight/2);
    if(save) try{localStorage.setItem(PKEY,JSON.stringify(p))}catch(e){}
  }
  try{
    var saved=JSON.parse(localStorage.getItem(PKEY)||'null');
    if(saved && typeof saved.x==='number') place(saved.x,saved.y,false);
  }catch(e){}

  btn.addEventListener('pointerdown',function(e){
    if(e.pointerType==='mouse' && e.button!==0) return;
    var r=wrap.getBoundingClientRect();
    sx=e.clientX; sy=e.clientY; ox=r.left; oy=r.top;
    moved=false; dragging=true; wrap.classList.add('dragging');
    try{btn.setPointerCapture(e.pointerId)}catch(err){}
  });
  btn.addEventListener('pointermove',function(e){
    if(!dragging) return;
    var dx=e.clientX-sx, dy=e.clientY-sy;
    if(!moved && (Math.abs(dx)>5 || Math.abs(dy)>5)){
      moved=true;
      if(opened){ opened=false; panel.hidden=true; }
    }
    if(!moved) return;
    e.preventDefault();
    place(ox+dx,oy+dy,false);
  });
  function endDrag(e){
    if(!dragging) return;
    dragging=false; wrap.classList.remove('dragging');
    if(moved){
      justDragged=true;
      var r=wrap.getBoundingClientRect();
      place(r.left,r.top,true);
    }
  }
  btn.addEventListener('pointerup',endDrag);
  btn.addEventListener('pointercancel',endDrag);
  btn.addEventListener('contextmenu',function(e){e.preventDefault()});
  window.addEventListener('resize',function(){
    var r=wrap.getBoundingClientRect();
    if(wrap.style.left) place(r.left,r.top,false);
  });

  document.addEventListener('pointerdown',function(e){
    if(!opened) return;
    if(!wrap.contains(e.target)){ opened=false; panel.hidden=true; }
  },true);
  document.addEventListener('keydown',function(e){
    if(e.key==='Escape' && opened){ opened=false; panel.hidden=true; }
  });

  function openTopup(){
    try{ if(window.Android&&window.Android.openUrl){ window.Android.openUrl(TOPUP); return; } }catch(e){}
    try{ window.open(TOPUP,'_blank','noopener'); }catch(e){ location.href=TOPUP; }
  }
  function bindTopup(){
    var list=panel.querySelectorAll('.dsb-topup');
    for(var i=0;i<list.length;i++){
      list[i].onclick=function(e){ e.stopPropagation(); openTopup(); };
    }
  }

  document.addEventListener('click',function(e){
    var m=e.target.closest&&e.target.closest('.dsb-more');
    if(m){ e.stopPropagation(); showStats(); }
  },true);

  btn.addEventListener('click',function(){
    if(justDragged){justDragged=false;return;}
    opened=!opened;
    if(opened) statsOpen=false;
    panel.hidden=!opened;
    if(opened) load(false);
  });

  document.addEventListener('visibilitychange',function(){
    if(!document.hidden) load(false);
  });

  (function(){
    try{
      if(localStorage.getItem('dsb-daily')) return;
      var old=JSON.parse(localStorage.getItem('dsb-spend')||'{}')||{};
      localStorage.setItem('dsb-daily',JSON.stringify(old));
    }catch(e){}
  })();

  (function(){
    try{
      if(localStorage.getItem('dsb-fix3')) return;
      var k=dayKey(new Date());
      var day=null; try{ day=JSON.parse(localStorage.getItem('dsb-day')||'null'); }catch(e){}
      var tp=topupMap();
      if(day && day.d===k && tp[k]){
        day.a=Math.max(0, Number(day.a)-Number(tp[k]));
        localStorage.setItem('dsb-day',JSON.stringify(day));
        tp[k]=0; saveTopup(tp);
        var o=dailyMap(); o[k]=0; saveDaily(o);
      }
      localStorage.setItem('dsb-fix3','1');
    }catch(e){}
  })();

  load(false);
  timer=setInterval(function(){ if(!document.hidden) load(false); },60000);
})();
