(function(){
  function put(s){
    var d=document.getElementById('dsb-asr-debug');
    if(!d){
      d=document.createElement('div'); d.id='dsb-asr-debug';
      d.style.cssText='position:fixed;left:8px;top:8px;right:8px;z-index:2147483647;background:rgba(0,0,0,.85);color:#7CFC00;font-size:11px;line-height:1.4;padding:8px;border-radius:8px;white-space:pre-wrap;max-height:40vh;overflow:auto';
      document.body.appendChild(d);
    }
    d.textContent += (d.textContent?'\n':'')+s;
  }
  put('debug ready');
  try{
    if(navigator.mediaDevices && navigator.mediaDevices.getUserMedia){
      var g=navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
      navigator.mediaDevices.getUserMedia=function(c){
        put('getUserMedia ...');
        return g(c).then(function(s){ put('mic ok'); return s; })
                    .catch(function(e){ put('mic FAIL '+(e&&e.name)+' '+(e&&e.message)); throw e; });
      };
    } else { put('no mediaDevices'); }
  }catch(e){ put('hook err '+e); }
  try{
    var f=window.fetch;
    window.fetch=function(input,init){
      var url=(typeof input==='string')?input:((input&&input.url)||'');
      var p=f.apply(this,arguments);
      if(url.indexOf('/v1/tools/asr')>=0){
        put('ASR request ...');
        p.then(function(r){
          put('ASR status '+r.status);
          try{ r.clone().text().then(function(t){ put('ASR body '+String(t).slice(0,300)); }); }catch(e){}
        }).catch(function(e){ put('ASR net FAIL '+e); });
      }
      return p;
    };
  }catch(e){ put('fetch hook err '+e); }
})();
