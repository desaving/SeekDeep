package com.seekdeep.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA = 1002;
    private static final int REQ_GALLERY = 1003;
    private static final int REQ_FILE = 1004;
    private static final int REQ_AUDIO = 200;

    private WebView web;
    private ValueCallback<Uri[]> pending;
    private Uri cameraUri;
    private File exportFile;
    private OutputStream exportOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
        }

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClientCompat() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        boolean ok = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
                        for (String r : request.getResources()) {
                            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && ok) {
                                request.grant(new String[]{r});
                                return;
                            }
                        }
                        request.deny();
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, WebChromeClient.FileChooserParams params) {
                if (pending != null) pending.onReceiveValue(null);
                pending = callback;
                showAttachmentMenu();
                return true;
            }
        });

        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void openUrl(String url) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) {}
            }

            @JavascriptInterface
            public void beginFile(String name) {
                try {
                    File dir = new File(getCacheDir(), "exports");
                    if (!dir.exists()) dir.mkdirs();
                    exportFile = new File(dir, name);
                    exportOut = new FileOutputStream(exportFile);
                } catch (Exception e) {
                    exportOut = null;
                    exportFile = null;
                }
            }

            @JavascriptInterface
            public void writeChunk(String b64) {
                try {
                    if (exportOut != null) exportOut.write(Base64.decode(b64, Base64.DEFAULT));
                } catch (Exception ignored) {}
            }

            @JavascriptInterface
            public void endFile() {
                try {
                    if (exportOut != null) { exportOut.close(); exportOut = null; }
                } catch (Exception ignored) {}
                final File f = exportFile;
                if (f == null) return;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Uri u = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", f);
                            Intent send = new Intent(Intent.ACTION_SEND);
                            send.setType("application/zip");
                            send.putExtra(Intent.EXTRA_STREAM, u);
                            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            startActivity(Intent.createChooser(send, "保存或分享导出文件"));
                        } catch (Exception ignored) {}
                    }
                });
            }

            @JavascriptInterface
            public void setUi(final boolean dark) {
                runOnUiThread(new Runnable() {
                    @Override public void run() { applyUi(dark); }
                });
            }
        }, "Android");

        applyUi(isDark());
        web.loadUrl("https://appassets.androidplatform.net/assets/www/index.html");
        setContentView(web);
    }

    private void showAttachmentMenu() {
        new AlertDialog.Builder(this)
                .setTitle("添加附件")
                .setItems(new String[]{"拍照", "从相册选择", "文件"}, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) takePhoto();
                        else if (which == 1) pickGallery();
                        else pickFile();
                    }
                })
                .setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialog) {
                        if (pending != null) {
                            pending.onReceiveValue(null);
                            pending = null;
                        }
                    }
                })
                .show();
    }

    private void takePhoto() {
        try {
            File dir = new File(getCacheDir(), "capture");
            if (!dir.exists()) dir.mkdirs();
            File img = new File(dir, "photo_" + System.currentTimeMillis() + ".jpg");
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", img);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(i, REQ_CAMERA);
        } catch (Exception e) {
            if (pending != null) { pending.onReceiveValue(null); pending = null; }
        }
    }

    private void pickGallery() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(i, REQ_GALLERY);
    }

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(i, REQ_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_CAMERA) {
            if (pending != null) {
                Uri[] result = (resultCode == RESULT_OK && cameraUri != null) ? new Uri[]{ cameraUri } : null;
                pending.onReceiveValue(result);
                pending = null;
                cameraUri = null;
            }
            return;
        }
        if (requestCode == REQ_GALLERY || requestCode == REQ_FILE) {
            if (pending != null) {
                Uri[] result = null;
                if (resultCode == RESULT_OK && data != null) {
                    if (data.getClipData() != null) {
                        ClipData clip = data.getClipData();
                        List<Uri> list = new ArrayList<>();
                        for (int i = 0; i < clip.getItemCount(); i++) {
                            Uri u = clip.getItemAt(i).getUri();
                            if (u != null) list.add(u);
                        }
                        result = list.toArray(new Uri[0]);
                    } else if (data.getData() != null) {
                        result = new Uri[]{ data.getData() };
                    }
                }
                pending.onReceiveValue(result);
                pending = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private boolean isDark() {
        return (getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK)
                == android.content.res.Configuration.UI_MODE_NIGHT_YES;
    }

    private void applyUi(boolean dark) {
        int bg = dark ? 0xFF1E1E20 : 0xFFFFFFFF;
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        if (web != null) web.setBackgroundColor(bg);
        View decor = getWindow().getDecorView();
        int flags = decor.getSystemUiVisibility();
        if (dark) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        else flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        decor.setSystemUiVisibility(flags);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
